#ifndef SoundPlayer_Included
#define SoundPlayer_Included

#include <string>

void playSound(const std::string& filename, double ms);

#endif
